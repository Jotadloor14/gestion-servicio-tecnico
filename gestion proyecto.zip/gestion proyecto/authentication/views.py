import json

from django.contrib.auth import authenticate, login
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_POST


@require_POST
@csrf_protect
def login_usuario(request):
    try:
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return JsonResponse({'error': 'Faltan credenciales'}, status=400)

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return JsonResponse({
                'message': 'Inicio de sesión exitoso',
                'usuario': user.username,
                'rol': user.rol
            }, status=200)
        else:
            return JsonResponse({'error': 'Credenciales inválidas'}, status=401)

    except json.JSONDecodeError:
        return JsonResponse({'error': 'JSON inválido'}, status=400)