from django.test import TestCase, Client
from django.contrib.auth import get_user_model

User = get_user_model()


class LoginTests(TestCase):

    def setUp(self):
        self.client = Client()
        self.username = "tecnico_test"
        self.password = "password123"

        # Crear el usuario de prueba
        self.user = User.objects.create_user(
            username=self.username, password=self.password
        )

    def test_login_exitoso(self):
        # Petición POST con la barra diagonal final en la URL
        response = self.client.post(
            "/api/login/",
            data={"username": self.username, "password": self.password},
            content_type="application/json",
        )

        # Verificar código 200
        self.assertEqual(response.status_code, 200)

        # Verificar respuesta con la clave 'message'
        response_data = response.json()
        self.assertEqual(response_data.get("message"), "Inicio de sesión exitoso")