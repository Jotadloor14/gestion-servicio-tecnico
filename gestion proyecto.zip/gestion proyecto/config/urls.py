from django.contrib import admin
from django.urls import path
from authentication.views import login_usuario

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/login/', login_usuario, name='login_usuario'),
]